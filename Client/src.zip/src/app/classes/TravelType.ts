export class TravelType{
    constructor(public TypeCode:Number, public TypeName:String){}
}